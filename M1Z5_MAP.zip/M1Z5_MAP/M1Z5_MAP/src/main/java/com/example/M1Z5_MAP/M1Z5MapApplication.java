package com.example.M1Z5_MAP;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class M1Z5MapApplication {

	public static void main(String[] args) {
		SpringApplication.run(M1Z5MapApplication.class, args);
	}

}
