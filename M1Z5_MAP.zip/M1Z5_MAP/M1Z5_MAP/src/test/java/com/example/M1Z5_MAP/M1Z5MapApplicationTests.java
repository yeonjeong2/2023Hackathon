package com.example.M1Z5_MAP;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class M1Z5MapApplicationTests {

	@Test
	void contextLoads() {
	}

}
